export default {
  news: 'Notícias',
  topmusic: 'Top Músicas',
  events: 'Eventos',
  timetable: 'Grade de Horários',
  podcasts: 'Podcasts',
  ads: 'Publicidades',
  photos: 'Fotos',
  videos: 'Vídeos'
};
