export default {
  access: 'Dicas de Acesso',
  pages: 'Gerenciar Páginas',
  publish: 'Publicar'
};
